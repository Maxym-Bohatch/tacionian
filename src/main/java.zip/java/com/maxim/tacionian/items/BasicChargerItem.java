package com.maxim.tacionian.items;

import com.maxim.tacionian.energy.PlayerEnergy;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.level.Level;

public class BasicChargerItem extends Item {

    public BasicChargerItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, net.minecraft.world.entity.player.Player player, InteractionHand hand) {
        if (level.isClientSide) return InteractionResultHolder.pass(player.getItemInHand(hand));

        if (player instanceof ServerPlayer sp) {
            PlayerEnergy.get(sp).ifPresent(energy -> {
                int drain = energy.extractEnergy(energy.getRegenRate() * 20, false);
                // поки що просто витрата, зарядку предметів підв’яжемо пізніше
            });
        }

        return InteractionResultHolder.success(player.getItemInHand(hand));
    }
}
