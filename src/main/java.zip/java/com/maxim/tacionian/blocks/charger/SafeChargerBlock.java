package com.maxim.tacionian.blocks.charger;

import com.maxim.tacionian.energy.PlayerEnergy;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class SafeChargerBlock extends Block implements EntityBlock {

    public SafeChargerBlock(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 net.minecraft.world.entity.player.Player player,
                                 InteractionHand hand, BlockHitResult hit) {

        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            PlayerEnergy.get(sp).ifPresent(energy -> {
                if (energy.getEnergyStored() > energy.getMaxEnergy() * 0.15) {
                    int drain = (int) (energy.getMaxEnergy() * 0.10);
                    energy.extractEnergy(drain, false);
                }
            });
        }
        return InteractionResult.SUCCESS;
    }

    @Override
    public ChargerBlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ChargerBlockEntity(pos, state);
    }
}
