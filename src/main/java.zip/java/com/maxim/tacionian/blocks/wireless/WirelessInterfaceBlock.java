package com.maxim.tacionian.blocks.wireless;

public class WirelessInterfaceBlock {
}
