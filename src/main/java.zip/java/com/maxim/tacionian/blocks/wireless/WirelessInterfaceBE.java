package com.maxim.tacionian.blocks.wireless;

public class WirelessInterfaceBE {
}
