package com.maxim.tacionian.blocks.charger;

import com.maxim.tacionian.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.energy.EnergyStorage;
import net.minecraftforge.energy.IEnergyStorage;

public class ChargerBlockEntity extends BlockEntity {

    private final EnergyStorage rfStorage = new EnergyStorage(100_000, 5_000);
    private final LazyOptional<IEnergyStorage> rfCap = LazyOptional.of(() -> rfStorage);

    public ChargerBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.CHARGER_BE.get(), pos, state);
    }

    @Override
    public <T> LazyOptional<T> getCapability(net.minecraftforge.common.capabilities.Capability<T> cap,
                                             net.minecraft.core.Direction side) {
        if (cap == ForgeCapabilities.ENERGY) {
            return rfCap.cast();
        }
        return super.getCapability(cap, side);
    }

    @Override
    public void invalidateCaps() {
        super.invalidateCaps();
        rfCap.invalidate();
    }
}
