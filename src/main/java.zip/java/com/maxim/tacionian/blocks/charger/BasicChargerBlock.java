package com.maxim.tacionian.blocks.charger;

import com.maxim.tacionian.energy.PlayerEnergy;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.Level;

public class BasicChargerBlock extends Block {

    public BasicChargerBlock(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, net.minecraft.world.entity.player.Player player,
                                 InteractionHand hand, BlockHitResult hit) {

        if (level.isClientSide) return InteractionResult.SUCCESS;

        if (player instanceof ServerPlayer sp) {
            PlayerEnergy.get(sp).ifPresent(energy -> {
                int drain = (int)(energy.getMaxEnergy() * 0.10f);
                energy.extractEnergy(drain, false);
                // RF вихід додамо в наступному кроці
            });
        }
        return InteractionResult.CONSUME;
    }
}
