package com.maxim.tacionian;

import com.maxim.tacionian.registry.ModBlockEntities;
import com.maxim.tacionian.registry.ModBlocks;
import com.maxim.tacionian.registry.ModItems;
import com.maxim.tacionian.energy.PlayerEnergyEvents;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import com.maxim.tacionian.network.NetworkHandler;

@Mod(Tacionian.MODID)
public class Tacionian {

    public static final String MODID = "tacionian";

    public Tacionian() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();

        ModBlocks.register(modBus);
       ModItems.register(modBus);
        ModBlockEntities.register(modBus);
        NetworkHandler.register();
        MinecraftForge.EVENT_BUS.register(new com.maxim.tacionian.command.CommandEvents());

        MinecraftForge.EVENT_BUS.register(new PlayerEnergyEvents());
    }
}
