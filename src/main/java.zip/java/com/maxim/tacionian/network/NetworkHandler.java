package com.maxim.tacionian.network;

import com.maxim.tacionian.Tacionian;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.SimpleChannel;

public class NetworkHandler {

    private static final String PROTOCOL = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(Tacionian.MODID, "main"),
            () -> PROTOCOL,
            PROTOCOL::equals,
            PROTOCOL::equals
    );

    private static int id = 0;

    public static void register() {
        CHANNEL.registerMessage(
                id++,
                PlayerEnergySyncPacket.class,
                PlayerEnergySyncPacket::encode,
                PlayerEnergySyncPacket::decode,
                PlayerEnergySyncPacket::handle
        );
    }
}
