package com.maxim.tacionian.network;

import com.maxim.tacionian.energy.ClientPlayerEnergy;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class PlayerEnergySyncPacket {

    private final int energy;
    private final int maxEnergy;
    private final boolean stabilized;
    private final boolean remoteStabilized;

    public PlayerEnergySyncPacket(int energy, int maxEnergy, boolean stabilized, boolean remoteStabilized) {
        this.energy = energy;
        this.maxEnergy = maxEnergy;
        this.stabilized = stabilized;
        this.remoteStabilized = remoteStabilized;
    }

    public static void encode(PlayerEnergySyncPacket msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.energy);
        buf.writeInt(msg.maxEnergy);
        buf.writeBoolean(msg.stabilized);
        buf.writeBoolean(msg.remoteStabilized);
    }

    public static PlayerEnergySyncPacket decode(FriendlyByteBuf buf) {
        return new PlayerEnergySyncPacket(
                buf.readInt(),
                buf.readInt(),
                buf.readBoolean(),
                buf.readBoolean()
        );
    }

    public static void handle(PlayerEnergySyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ClientPlayerEnergy.update(
                    msg.energy,
                    msg.maxEnergy,
                    msg.stabilized,
                    msg.remoteStabilized
            );
        });
        ctx.get().setPacketHandled(true);
    }
}
