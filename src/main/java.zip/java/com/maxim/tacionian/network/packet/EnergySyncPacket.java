package com.maxim.tacionian.network.packet;

import com.maxim.tacionian.energy.ClientPlayerEnergy;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class EnergySyncPacket {

    private final int energy;
    private final int maxEnergy;
    private final int regenRate;

    private final boolean criticalLow;
    private final boolean overloaded;
    private final boolean stabilized;
    private final boolean remoteStabilized;

    public EnergySyncPacket(
            int energy,
            int maxEnergy,
            int regenRate,
            boolean criticalLow,
            boolean overloaded,
            boolean stabilized,
            boolean remoteStabilized
    ) {
        this.energy = energy;
        this.maxEnergy = maxEnergy;
        this.regenRate = regenRate;
        this.criticalLow = criticalLow;
        this.overloaded = overloaded;
        this.stabilized = stabilized;
        this.remoteStabilized = remoteStabilized;
    }

    public EnergySyncPacket(FriendlyByteBuf buf) {
        energy = buf.readInt();
        maxEnergy = buf.readInt();
        regenRate = buf.readInt();
        criticalLow = buf.readBoolean();
        overloaded = buf.readBoolean();
        stabilized = buf.readBoolean();
        remoteStabilized = buf.readBoolean();
    }

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(energy);
        buf.writeInt(maxEnergy);
        buf.writeInt(regenRate);
        buf.writeBoolean(criticalLow);
        buf.writeBoolean(overloaded);
        buf.writeBoolean(stabilized);
        buf.writeBoolean(remoteStabilized);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ClientPlayerEnergy.update(
                    energy,
                    maxEnergy,
                    regenRate,
                    criticalLow,
                    overloaded,
                    stabilized,
                    remoteStabilized
            );
        });
        ctx.get().setPacketHandled(true);
    }
}
