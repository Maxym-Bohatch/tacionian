package com.maxim.tacionian.registry;

import com.maxim.tacionian.Tacionian;
import com.maxim.tacionian.blocks.charger.BasicChargerBlock;
import com.maxim.tacionian.blocks.charger.SafeChargerBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Tacionian.MODID);

    public static final RegistryObject<Block> BASIC_CHARGER =
            BLOCKS.register("basic_charger",
                    () -> new BasicChargerBlock(
                            BlockBehaviour.Properties.of()
                                    .mapColor(MapColor.METAL)
                                    .strength(4.0f)
                                    .sound(SoundType.METAL)
                    ));

    public static final RegistryObject<Block> SAFE_CHARGER =
            BLOCKS.register("safe_charger",
                    () -> new SafeChargerBlock(
                            BlockBehaviour.Properties.of()
                                    .mapColor(MapColor.METAL)
                                    .strength(4.5f)
                                    .sound(SoundType.METAL)
                    ));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }
}
