package com.maxim.tacionian.registry;

import com.maxim.tacionian.Tacionian;
import com.maxim.tacionian.blocks.charger.ChargerBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Tacionian.MODID);

    public static final RegistryObject<BlockEntityType<ChargerBlockEntity>> CHARGER_BE =
            BLOCK_ENTITIES.register("charger_be",
                    () -> BlockEntityType.Builder.of(
                            ChargerBlockEntity::new,
                            ModBlocks.BASIC_CHARGER.get(),
                            ModBlocks.SAFE_CHARGER.get()
                    ).build(null)
            );

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
    }
}
