package com.maxim.tacionian.registry;

public class ModCreativeTabs {
}
