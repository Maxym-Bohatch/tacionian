package com.maxim.tacionian.util;

public class EnergyMath {
}
