package com.maxim.tacionian.energy;

import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.CapabilityManager;
import net.minecraftforge.common.capabilities.ICapabilitySerializable;
import net.minecraftforge.common.capabilities.RegisterCapabilitiesEvent;
import net.minecraftforge.common.util.LazyOptional;

import javax.annotation.Nullable;

public class PlayerEnergyProvider implements ICapabilitySerializable<CompoundTag> {

    public static Capability<PlayerEnergy> PLAYER_ENERGY;

    private final PlayerEnergy energy = new PlayerEnergy();
    private final LazyOptional<PlayerEnergy> optional = LazyOptional.of(() -> energy);

    /* ===== REGISTRATION ===== */

    public static void register(RegisterCapabilitiesEvent event) {
        event.register(PlayerEnergy.class);
    }

    /* ===== CAPABILITY ===== */

    @Override
    public <T> LazyOptional<T> getCapability(Capability<T> cap, @Nullable Direction side) {
        return cap == PLAYER_ENERGY ? optional.cast() : LazyOptional.empty();
    }

    /* ===== NBT ===== */

    @Override
    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        energy.saveNBT(tag);
        return tag;
    }

    @Override
    public void deserializeNBT(CompoundTag tag) {
        energy.loadNBT(tag);
    }
}
