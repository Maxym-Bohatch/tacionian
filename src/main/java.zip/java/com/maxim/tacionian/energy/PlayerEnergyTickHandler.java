package com.maxim.tacionian.energy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import com.maxim.tacionian.network.NetworkHandler;
import com.maxim.tacionian.network.PlayerEnergySyncPacket;
import net.minecraftforge.network.PacketDistributor;

@Mod.EventBusSubscriber
public class PlayerEnergyTickHandler {

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer player)) return;

        player.getCapability(PlayerEnergyProvider.PLAYER_ENERGY).ifPresent(energy -> {

            /* ===== REGEN ===== */
            energy.tickRegen();

            /* ===== LOW ENERGY EFFECTS ===== */
            if (energy.isCriticalLow()) {
                player.addEffect(new MobEffectInstance(
                        MobEffects.HUNGER, 40, 0, true, false
                ));
                player.addEffect(new MobEffectInstance(
                        MobEffects.DARKNESS, 40, 0, true, false
                ));
            }

            /* ===== OVERLOAD ===== */
            if (energy.isOverloaded()) {
                player.addEffect(new MobEffectInstance(
                        MobEffects.MOVEMENT_SLOWDOWN, 40, 1, true, false
                ));
                player.addEffect(new MobEffectInstance(
                        MobEffects.WEAKNESS, 40, 1, true, false
                ));
            }

            /* ===== CAPACITY LOGIC ===== */
            boolean goodBalance =
                    !energy.isCriticalLow() &&
                            !energy.isOverloaded() &&
                            !energy.isStabilized() &&
                            !energy.isRemoteStabilized();

            if (player.tickCount % 200 == 0) {
                energy.adjustCapacity(goodBalance);
            }
            NetworkHandler.CHANNEL.send(
                    PacketDistributor.PLAYER.with(() -> player),
                    new PlayerEnergySyncPacket(
                            energy.getEnergy(),
                            energy.getMaxEnergy(),
                            energy.isStabilized(),
                            energy.isRemoteStabilized()
                    )
            );

        });
    }
}
