package com.maxim.tacionian.energy;

public class PlayerEnergyImpl {
}
