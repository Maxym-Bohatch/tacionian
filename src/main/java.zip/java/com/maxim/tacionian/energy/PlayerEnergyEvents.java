package com.maxim.tacionian.energy;

import com.maxim.tacionian.network.NetworkHandler;
import com.maxim.tacionian.network.packet.EnergySyncPacket;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

import static com.maxim.tacionian.energy.ClientPlayerEnergy.energy;

public class PlayerEnergyEvents {

    /* ===== SERVER TICK ===== */
    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent event) {
        PlayerEnergyEffects.apply(sp, energy);

        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer sp)) return;

        PlayerEnergy.get(sp).ifPresent(energy -> {

            energy.tickRegen();
            energy.applyBalanceLogic();

            NetworkHandler.sendToPlayer(
                    sp,
                    new EnergySyncPacket(
                            energy.getEnergy(),
                            energy.getMaxEnergy(),
                            energy.getRegenRate(),
                            energy.isCriticalLow(),
                            energy.isOverloaded(),
                            energy.isStabilized(),
                            energy.isRemoteStabilized()
                    )
            );
        });
    }

    /* ===== CLONE (death / dimension change) ===== */
    @SubscribeEvent
    public void onClone(PlayerEvent.Clone event) {
        if (!(event.getEntity() instanceof ServerPlayer sp)) return;

        PlayerEnergy.get(sp).ifPresent(newEnergy ->
                PlayerEnergy.get((ServerPlayer) event.getOriginal()).ifPresent(oldEnergy ->
                        newEnergy.deserializeNBT(oldEnergy.serializeNBT())
                )
        );
    }
}
