package com.maxim.tacionian.energy;

public class ClientPlayerEnergy {

    private static int energy;
    private static int maxEnergy;
    private static int regenRate;

    private static boolean criticalLow;
    private static boolean overloaded;
    private static boolean stabilized;
    private static boolean remoteStabilized;

    public static void update(
            int e,
            int max,
            int regen,
            boolean critLow,
            boolean over,
            boolean stab,
            boolean remoteStab
    ) {
        energy = e;
        maxEnergy = max;
        regenRate = regen;
        criticalLow = critLow;
        overloaded = over;
        stabilized = stab;
        remoteStabilized = remoteStab;
    }

    public static int getEnergy() {
        return energy;
    }

    public static int getMaxEnergy() {
        return maxEnergy;
    }

    public static float getRatio() {
        if (maxEnergy <= 0) return 0;
        return (float) energy / (float) maxEnergy;
    }

    public static int getRegenRate() {
        return regenRate;
    }

    public static boolean isCriticalLow() {
        return criticalLow;
    }

    public static boolean isOverloaded() {
        return overloaded;
    }

    public static boolean isStabilized() {
        return stabilized;
    }

    public static boolean isRemoteStabilized() {
        return remoteStabilized;
    }
}
