package com.maxim.tacionian.energy;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;

public class PlayerEnergyEffects {

    public static void apply(ServerPlayer player, PlayerEnergy energy) {

        if (energy.isCriticalLow()) {
            player.addEffect(new MobEffectInstance(
                    MobEffects.HUNGER, 40, 0, true, false
            ));
            player.addEffect(new MobEffectInstance(
                    MobEffects.DARKNESS, 40, 0, true, false
            ));
            return;
        }

        if (energy.isOverloaded()) {
            player.addEffect(new MobEffectInstance(
                    MobEffects.CONFUSION, 60, 1, true, false
            ));
            player.addEffect(new MobEffectInstance(
                    MobEffects.MOVEMENT_SLOWDOWN, 40, 1, true, false
            ));
        }
    }
}
