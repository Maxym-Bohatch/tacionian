package com.maxim.tacionian.energy;

import net.minecraft.nbt.CompoundTag;

public class PlayerEnergy {

    /* ===== CONSTANTS ===== */
    public static final int BASE_MAX_ENERGY = 10000;
    public static final int MIN_SAFE_ENERGY = 500;

    /* ===== DATA ===== */
    private int energy;
    private int maxEnergy;

    private boolean stabilized;
    private boolean remoteStabilized;

    /* ===== INIT ===== */
    public PlayerEnergy() {
        this.maxEnergy = BASE_MAX_ENERGY;
        this.energy = maxEnergy / 2;
    }

    /* ===== GETTERS ===== */

    public int getEnergy() {
        return energy;
    }

    public int getMaxEnergy() {
        return maxEnergy;
    }

    public float getEnergyRatio() {
        if (maxEnergy <= 0) return 0;
        return (float) energy / (float) maxEnergy;
    }

    /* ===== STATES ===== */

    public boolean isCriticalLow() {
        return energy <= MIN_SAFE_ENERGY;
    }

    public boolean isOverloaded() {
        return energy >= maxEnergy * 0.97f;
    }

    public boolean isCritical() {
        return isCriticalLow() || isOverloaded();
    }

    public boolean isStabilized() {
        return stabilized;
    }

    public boolean isRemoteStabilized() {
        return remoteStabilized;
    }

    /* ===== MODIFIERS ===== */

    public void setStabilized(boolean value) {
        stabilized = value;
    }

    public void setRemoteStabilized(boolean value) {
        remoteStabilized = value;
    }
    public void forceSetMaxEnergy(int value) {
        maxEnergy = Math.max(value, BASE_MAX_ENERGY);
        energy = Math.min(energy, maxEnergy);
    }
    public void applyBalanceLogic() {
        if (isCriticalLow()) {
            adjustCapacity(false);
        } else if (!isOverloaded()) {
            adjustCapacity(true);
        }
    }

    /* ===== ENERGY FLOW ===== */

    public int extractEnergy(int amount, boolean simulate) {
        int extracted = Math.min(amount, energy);
        if (!simulate) {
            energy -= extracted;
        }
        return extracted;
    }

    public int receiveEnergy(int amount, boolean simulate) {
        int received = Math.min(amount, maxEnergy - energy);
        if (!simulate) {
            energy += received;
        }
        return received;
    }

    /* ===== REGEN LOGIC ===== */

    /**
     * Єдине джерело правди для швидкості регену.
     * HUD і ефекти повинні орієнтуватись на це.
     */
    public int getRegenRate() {
        if (stabilized || remoteStabilized) return 0;

        if (isCriticalLow()) return 3;
        if (energy > maxEnergy * 0.75f) return 2;
        return 1;
    }

    public void tickRegen() {
        int regen = getRegenRate();
        if (regen > 0) {
            receiveEnergy(regen, false);
        }
    }

    /* ===== CAPACITY EVOLUTION ===== */

    public void adjustCapacity(boolean goodBalance) {
        if (goodBalance) {
            maxEnergy = Math.min(maxEnergy + 10, BASE_MAX_ENERGY * 5);
        } else {
            maxEnergy = Math.max(BASE_MAX_ENERGY, maxEnergy - 20);
            energy = Math.min(energy, maxEnergy);
        }
    }

    /* ===== NBT ===== */

    public CompoundTag serializeNBT() {
        CompoundTag tag = new CompoundTag();
        tag.putInt("Energy", energy);
        tag.putInt("MaxEnergy", maxEnergy);
        tag.putBoolean("Stabilized", stabilized);
        tag.putBoolean("RemoteStabilized", remoteStabilized);
        return tag;
    }

    public void deserializeNBT(CompoundTag tag) {
        energy = tag.getInt("Energy");
        maxEnergy = tag.getInt("MaxEnergy");
        stabilized = tag.getBoolean("Stabilized");
        remoteStabilized = tag.getBoolean("RemoteStabilized");
    }
}
