package com.maxim.tacionian.command;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class CommandEvents {

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        com.maxim.tacionian.command.TacionianCommand.register(event.getDispatcher());
    }
}
