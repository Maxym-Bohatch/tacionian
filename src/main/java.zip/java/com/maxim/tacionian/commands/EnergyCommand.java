package com.maxim.tacionian.commands;

import com.maxim.tacionian.energy.PlayerEnergy;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;

public class EnergyCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {

        dispatcher.register(
                Commands.literal("tacionian")
                        .then(Commands.literal("energy")
                                .requires(cs -> cs.hasPermission(2))
                                .then(Commands.literal("set")
                                        .then(Commands.argument("value", IntegerArgumentType.integer(0))
                                                .executes(ctx -> {
                                                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                    int value = IntegerArgumentType.getInteger(ctx, "value");

                                                    PlayerEnergy.get(player).ifPresent(energy -> {
                                                        energy.setEnergy(value);
                                                        energy.sync(player);
                                                    });

                                                    return 1;
                                                })
                                        )
                                )
                                .then(Commands.literal("add")
                                        .then(Commands.argument("value", IntegerArgumentType.integer())
                                                .executes(ctx -> {
                                                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                    int value = IntegerArgumentType.getInteger(ctx, "value");

                                                    PlayerEnergy.get(player).ifPresent(energy -> {
                                                        energy.receiveEnergy(value, false);
                                                        energy.sync(player);
                                                    });

                                                    return 1;
                                                })
                                        )
                                )
                        )
        );
    }
}
