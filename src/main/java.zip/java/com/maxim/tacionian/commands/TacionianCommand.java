package com.maxim.tacionian.command;

import com.maxim.tacionian.energy.PlayerEnergy;
import com.maxim.tacionian.network.NetworkHandler;
import com.maxim.tacionian.network.packet.EnergySyncPacket;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;

public class TacionianCommand {

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {

        dispatcher.register(
                Commands.literal("tacionian")
                        .requires(src -> src.hasPermission(2)) // OP
                        .then(
                                Commands.literal("energy")

                                        // ===== GET =====
                                        .then(Commands.literal("get")
                                                .executes(ctx -> {
                                                    ServerPlayer player = ctx.getSource().getPlayerOrException();

                                                    PlayerEnergy.get(player).ifPresent(energy -> {
                                                        ctx.getSource().sendSuccess(
                                                                () -> Component.literal(
                                                                        "Energy: " + energy.getEnergy() +
                                                                                " / " + energy.getMaxEnergy() +
                                                                                " | Regen: " + energy.getRegenRate() + "/t"
                                                                ),
                                                                false
                                                        );
                                                    });
                                                    return 1;
                                                })
                                        )

                                        // ===== SET =====
                                        .then(Commands.literal("set")
                                                .then(Commands.argument("value", IntegerArgumentType.integer(0))
                                                        .executes(ctx -> {
                                                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                            int value = IntegerArgumentType.getInteger(ctx, "value");

                                                            PlayerEnergy.get(player).ifPresent(energy -> {
                                                                energy.receiveEnergy(value - energy.getEnergy(), false);
                                                                sync(player, energy);
                                                            });
                                                            return 1;
                                                        })
                                                )
                                        )

                                        // ===== ADD =====
                                        .then(Commands.literal("add")
                                                .then(Commands.argument("value", IntegerArgumentType.integer())
                                                        .executes(ctx -> {
                                                            ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                            int value = IntegerArgumentType.getInteger(ctx, "value");

                                                            PlayerEnergy.get(player).ifPresent(energy -> {
                                                                if (value >= 0) {
                                                                    energy.receiveEnergy(value, false);
                                                                } else {
                                                                    energy.extractEnergy(-value, false);
                                                                }
                                                                sync(player, energy);
                                                            });
                                                            return 1;
                                                        })
                                                )
                                        )

                                        // ===== MAX SET =====
                                        .then(Commands.literal("max")
                                                .then(Commands.literal("set")
                                                        .then(Commands.argument("value", IntegerArgumentType.integer(100))
                                                                .executes(ctx -> {
                                                                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                                                                    int value = IntegerArgumentType.getInteger(ctx, "value");

                                                                    PlayerEnergy.get(player).ifPresent(energy -> {
                                                                        energy.forceSetMaxEnergy(value);
                                                                        sync(player, energy);
                                                                    });
                                                                    return 1;
                                                                })
                                                        )
                                                )
                                        )

                                        // ===== DEBUG =====
                                        .then(Commands.literal("debug")
                                                .executes(ctx -> {
                                                    ServerPlayer player = ctx.getSource().getPlayerOrException();

                                                    PlayerEnergy.get(player).ifPresent(e -> {
                                                        ctx.getSource().sendSuccess(
                                                                () -> Component.literal(
                                                                        "[DEBUG]\n" +
                                                                                "Energy: " + e.getEnergy() + "/" + e.getMaxEnergy() + "\n" +
                                                                                "CriticalLow: " + e.isCriticalLow() + "\n" +
                                                                                "Overloaded: " + e.isOverloaded() + "\n" +
                                                                                "Stabilized: " + e.isStabilized() + "\n" +
                                                                                "RemoteStabilized: " + e.isRemoteStabilized()
                                                                ),
                                                                false
                                                        );
                                                    });
                                                    return 1;
                                                })
                                        )
                        )
        );
    }

    /* ===== SYNC ===== */
    private static void sync(ServerPlayer player, PlayerEnergy energy) {
        NetworkHandler.sendToPlayer(
                player,
                new EnergySyncPacket(
                        energy.getEnergy(),
                        energy.getMaxEnergy(),
                        energy.getRegenRate(),
                        energy.isCriticalLow(),
                        energy.isOverloaded(),
                        energy.isStabilized(),
                        energy.isRemoteStabilized()
                )
        );
    }
}
