package com.maxim.tacionian.client.hud;

import com.maxim.tacionian.energy.ClientPlayerEnergy;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

public class EnergyHudOverlay {

    public static final IGuiOverlay HUD = (gui, graphics, partialTick, width, height) -> {

        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        int energy = ClientPlayerEnergy.getEnergy();
        int maxEnergy = ClientPlayerEnergy.getMaxEnergy();
        if (maxEnergy <= 0) return;

        int x = 10;
        int y = 10;
        int barWidth = 80;
        int barHeight = 8;

        int filled = (int) (barWidth * ClientPlayerEnergy.getRatio());

        int color;

        if (ClientPlayerEnergy.isRemoteStabilized()) {
            color = 0xFFAA00FF; // фіолетовий
        } else if (ClientPlayerEnergy.isStabilized()) {
            color = 0xFF00FF00; // зелений
        } else if (ClientPlayerEnergy.isCriticalLow() || ClientPlayerEnergy.isOverloaded()) {
            color = 0xFFFF0000; // червоний
        } else {
            color = 0xFF00A0FF; // голубий
        }

        // рамка
        graphics.fill(x - 1, y - 1, x + barWidth + 1, y + barHeight + 1, 0xFF000000);
        // заповнення
        graphics.fill(x, y, x + filled, y + barHeight, color);

        // ==== ТЕКСТ ПІД HUD ====
        int regen = ClientPlayerEnergy.getRegenRate();
        String text = energy + " / " + maxEnergy + " (+" + regen + "/t)";

        int textWidth = mc.font.width(text);
        graphics.drawString(
                mc.font,
                text,
                x + barWidth / 2 - textWidth / 2,
                y + barHeight + 4,
                0xFFFFFF,
                false
        );
    };
}
